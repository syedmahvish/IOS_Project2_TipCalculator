//
//  ViewController.swift
//  TipCalculator
//
//  Created by Mahvish Syed on 25/04/21.
//  Copyright © 2021 Mahvish Syed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultTextfield: UITextField!
    
    @IBOutlet weak var tipLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!

    @IBOutlet weak var totalLabel: UILabel!
    
    @IBOutlet weak var slider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultTextfield.keyboardType = .numberPad
        addDoneButtonKeyboard()
    }
    
    func addDoneButtonKeyboard(){
        var toolbar : UIToolbar = UIToolbar(frame: CGRect(x: 0,y: 0,width: self.view.frame.width, height: 40))
        var flexbarButton : UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        var doneButton : UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        toolbar.items = [flexbarButton, doneButton]
        
        resultTextfield.inputAccessoryView = toolbar
    }
    
    @objc func doneButtonAction(){
        resultTextfield.resignFirstResponder()
    }
    

    @IBAction func sliderValueChangeFunction(_ sender: UISlider) {
        guard let value = sender.value as? Float,
              let valueInt = Int(value) as? Int,
              let enteredValue = resultTextfield.text as? String,
              let enteredValueInt = Float(enteredValue) as? Float
            else { return}
        
        
      tipLabel.text = "Tip (" + String(valueInt) + "%)"
      let tipAmount = Float(enteredValueInt * (value/100))
      tipAmountLabel.text =  String(format:  "%.3f", tipAmount)
      let totalAmount = enteredValueInt + tipAmount
      totalLabel.text = String(format: "%.3f", totalAmount)
    }
    
    
}

